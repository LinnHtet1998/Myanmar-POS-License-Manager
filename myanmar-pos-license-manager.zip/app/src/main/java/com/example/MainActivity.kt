package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.localization.LocalAppStrings
import com.example.core.localization.stringsFor
import com.example.di.AppContainer
import com.example.ui.navigation.AppNavHost
import com.example.ui.theme.MyanmarPosLicenseTheme
import com.example.ui.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val appContainer = remember { AppContainer(applicationContext) }
            val appViewModel: AppViewModel = viewModel(
                factory = AppViewModel.Factory(
                    preferencesRepository = appContainer.preferencesRepository,
                    authRepository = appContainer.authRepository,
                ),
            )
            val appUiState by appViewModel.uiState.collectAsStateWithLifecycle()
            val localizedStrings = remember(appUiState.language) {
                stringsFor(appUiState.language)
            }

            CompositionLocalProvider(LocalAppStrings provides localizedStrings) {
                MyanmarPosLicenseTheme(themePreference = appUiState.themePreference) {
                    AppNavHost(
                        appContainer = appContainer,
                        appViewModel = appViewModel,
                        appUiState = appUiState,
                    )
                }
            }
        }
    }
}
