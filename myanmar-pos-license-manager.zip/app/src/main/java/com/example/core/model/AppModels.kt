package com.example.core.model

enum class AppLanguage(val code: String) {
    MYANMAR("my"),
    ENGLISH("en");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: MYANMAR
    }
}

enum class ThemePreference(val key: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    companion object {
        fun fromKey(key: String?): ThemePreference =
            entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

enum class WindowWidthSize {
    COMPACT,
    MEDIUM,
    EXPANDED,
}

data class OwnerSession(
    val email: String,
    val signedInAtMillis: Long,
    val isStageOneLocalSession: Boolean = true,
)

data class LicenseOverviewSnapshot(
    val totalLicenses: Int? = null,
    val activeTerminals: Int? = null,
    val expiringSoon: Int? = null,
    val revokedOrPaused: Int? = null,
    val isBackendConnected: Boolean = false,
)

enum class RoadmapStepId {
    ARCHITECTURE_AND_NAV,
    RESPONSIVE_BURMESE_UI,
    FIREBASE_AUTH_SYNC,
    LICENSE_KEY_LIFECYCLE,
}

data class ReadinessRoadmapItem(
    val id: RoadmapStepId,
    val isReadyInStageOne: Boolean,
)
