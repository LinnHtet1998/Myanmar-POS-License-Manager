package com.example.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.model.LicenseOverviewSnapshot
import com.example.core.model.OwnerSession
import com.example.core.model.ReadinessRoadmapItem
import com.example.core.model.RoadmapStepId
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.LicenseRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val ownerEmail: String = "",
    val overview: LicenseOverviewSnapshot = LicenseOverviewSnapshot(),
    val roadmapItems: List<ReadinessRoadmapItem> = listOf(
        ReadinessRoadmapItem(RoadmapStepId.ARCHITECTURE_AND_NAV, isReadyInStageOne = true),
        ReadinessRoadmapItem(RoadmapStepId.RESPONSIVE_BURMESE_UI, isReadyInStageOne = true),
        ReadinessRoadmapItem(RoadmapStepId.FIREBASE_AUTH_SYNC, isReadyInStageOne = false),
        ReadinessRoadmapItem(RoadmapStepId.LICENSE_KEY_LIFECYCLE, isReadyInStageOne = false),
    ),
)

class DashboardViewModel(
    authRepository: AuthRepository,
    licenseRepository: LicenseRepository,
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = combine(
        authRepository.sessionState,
        licenseRepository.overviewState,
    ) { session: OwnerSession?, overview: LicenseOverviewSnapshot ->
        DashboardUiState(
            ownerEmail = session?.email.orEmpty(),
            overview = overview,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = DashboardUiState(),
    )

    class Factory(
        private val authRepository: AuthRepository,
        private val licenseRepository: LicenseRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(authRepository, licenseRepository) as T
        }
    }
}
