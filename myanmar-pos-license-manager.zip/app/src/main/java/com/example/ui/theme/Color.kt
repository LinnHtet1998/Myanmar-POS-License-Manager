package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Core — Imperial Jade & Sovereign Gold
val JadePrimaryLight = Color(0xFF0A5C4B)
val OnJadePrimaryLight = Color(0xFFFFFFFF)
val JadePrimaryContainerLight = Color(0xFFA7F3DC)
val OnJadePrimaryContainerLight = Color(0xFF002019)

val GoldSecondaryLight = Color(0xFF8A6418)
val OnGoldSecondaryLight = Color(0xFFFFFFFF)
val GoldSecondaryContainerLight = Color(0xFFFFDEA6)
val OnGoldSecondaryContainerLight = Color(0xFF2B1C00)

val SlateTertiaryLight = Color(0xFF2F5E72)
val OnSlateTertiaryLight = Color(0xFFFFFFFF)
val SlateTertiaryContainerLight = Color(0xFFC2E8FA)
val OnSlateTertiaryContainerLight = Color(0xFF001E29)

val SurfaceLight = Color(0xFFF6F9F7)
val OnSurfaceLight = Color(0xFF151D1A)
val SurfaceVariantLight = Color(0xFFDCE5E0)
val OnSurfaceVariantLight = Color(0xFF3F4944)
val OutlineLight = Color(0xFF6F7974)
val OutlineVariantLight = Color(0xFFBFC9C4)

val SurfaceContainerLowestLight = Color(0xFFFFFFFF)
val SurfaceContainerLowLight = Color(0xFFF0F5F2)
val SurfaceContainerLight = Color(0xFFEAEFEC)
val SurfaceContainerHighLight = Color(0xFFE4EAE6)
val SurfaceContainerHighestLight = Color(0xFFDEE4E0)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

// Dark Theme Palette — Deep Jade Obsidian
val JadePrimaryDark = Color(0xFF7AD6BC)
val OnJadePrimaryDark = Color(0xFF00382C)
val JadePrimaryContainerDark = Color(0xFF005141)
val OnJadePrimaryContainerDark = Color(0xFFA7F3DC)

val GoldSecondaryDark = Color(0xFFE7C271)
val OnGoldSecondaryDark = Color(0xFF463000)
val GoldSecondaryContainerDark = Color(0xFF644700)
val OnGoldSecondaryContainerDark = Color(0xFFFFDEA6)

val SlateTertiaryDark = Color(0xFFA6CCE0)
val OnSlateTertiaryDark = Color(0xFF093545)
val SlateTertiaryContainerDark = Color(0xFF214B5C)
val OnSlateTertiaryContainerDark = Color(0xFFC2E8FA)

val SurfaceDark = Color(0xFF0D1412)
val OnSurfaceDark = Color(0xFFDEE4E0)
val SurfaceVariantDark = Color(0xFF3B4540)
val OnSurfaceVariantDark = Color(0xFFBFC9C4)
val OutlineDark = Color(0xFF89938E)
val OutlineVariantDark = Color(0xFF3F4944)

val SurfaceContainerLowestDark = Color(0xFF080E0C)
val SurfaceContainerLowDark = Color(0xFF141C19)
val SurfaceContainerDark = Color(0xFF18211E)
val SurfaceContainerHighDark = Color(0xFF222B28)
val SurfaceContainerHighestDark = Color(0xFF2D3633)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

// Brand Showcase Constants (used in branded hero panels)
val DeepImperialJade = Color(0xFF0C4137)
val DeepImperialJadeDark = Color(0xFF072B24)
val SovereignGold = Color(0xFFD4A039)
