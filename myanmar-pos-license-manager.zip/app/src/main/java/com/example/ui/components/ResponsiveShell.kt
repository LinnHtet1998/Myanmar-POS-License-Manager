package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.localization.LocalAppStrings
import com.example.core.model.AppLanguage
import com.example.core.model.WindowWidthSize

enum class PrimaryTab(
    val testTag: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
) {
    DASHBOARD("nav_dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    LICENSES("nav_licenses", Icons.Filled.VpnKey, Icons.Outlined.VpnKey),
    SETTINGS("nav_settings", Icons.Filled.Settings, Icons.Outlined.Settings),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResponsiveOwnerShell(
    selectedTab: PrimaryTab,
    currentLanguage: AppLanguage,
    onSelectTab: (PrimaryTab) -> Unit,
    onToggleLanguage: () -> Unit,
    onRequestSignOut: () -> Unit,
    content: @Composable (WindowWidthSize) -> Unit,
) {
    val strings = LocalAppStrings.current

    fun tabLabel(tab: PrimaryTab): String = when (tab) {
        PrimaryTab.DASHBOARD -> strings.navDashboard
        PrimaryTab.LICENSES -> strings.navLicenses
        PrimaryTab.SETTINGS -> strings.navSettings
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val widthSize = when {
            maxWidth >= 840.dp -> WindowWidthSize.EXPANDED
            maxWidth >= 600.dp -> WindowWidthSize.MEDIUM
            else -> WindowWidthSize.COMPACT
        }
        val useNavigationRail = widthSize != WindowWidthSize.COMPACT

        if (useNavigationRail) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.navigationBars),
            ) {
                NavigationRail(
                    modifier = Modifier
                        .fillMaxHeight()
                        .windowInsetsPadding(WindowInsets.statusBars),
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(top = 12.dp, bottom = 16.dp),
                        ) {
                            BrandEmblemBadge(size = 44.dp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "POS",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    },
                ) {
                    Spacer(modifier = Modifier.height(8.dp))
                    PrimaryTab.entries.forEach { tab ->
                        val isSelected = tab == selectedTab
                        val label = tabLabel(tab)
                        NavigationRailItem(
                            selected = isSelected,
                            onClick = { onSelectTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = label,
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            modifier = Modifier.testTag(tab.testTag),
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    IconButton(
                        onClick = onRequestSignOut,
                        modifier = Modifier
                            .padding(bottom = 16.dp)
                            .testTag("rail_sign_out_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.Logout,
                            contentDescription = strings.settingsSignOutButton,
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                }

                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Scaffold(
                    modifier = Modifier.weight(1f),
                    containerColor = MaterialTheme.colorScheme.background,
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    Text(
                                        text = tabLabel(selectedTab),
                                        style = MaterialTheme.typography.titleLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    StageStatusChip(text = strings.stageOneBadge)
                                }
                            },
                            actions = {
                                LanguageTogglePill(
                                    currentLanguage = currentLanguage,
                                    onToggle = onToggleLanguage,
                                    modifier = Modifier.padding(end = 12.dp),
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background,
                            ),
                        )
                    },
                ) { innerPadding ->
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        color = MaterialTheme.colorScheme.background,
                    ) {
                        content(widthSize)
                    }
                }
            }
        } else {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                BrandEmblemBadge(size = 34.dp)
                                Column {
                                    Text(
                                        text = tabLabel(selectedTab),
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = strings.appName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        },
                        actions = {
                            LanguageTogglePill(
                                currentLanguage = currentLanguage,
                                onToggle = onToggleLanguage,
                                modifier = Modifier.padding(end = 8.dp),
                            )
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background,
                        ),
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                        windowInsets = WindowInsets.navigationBars,
                    ) {
                        PrimaryTab.entries.forEach { tab ->
                            val isSelected = tab == selectedTab
                            val label = tabLabel(tab)
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { onSelectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = label,
                                    )
                                },
                                label = {
                                    Text(
                                        text = label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                modifier = Modifier.testTag(tab.testTag),
                            )
                        }
                    }
                },
            ) { innerPadding ->
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    content(widthSize)
                }
            }
        }
    }
}
