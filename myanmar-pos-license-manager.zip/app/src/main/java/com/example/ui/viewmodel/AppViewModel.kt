package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.model.AppLanguage
import com.example.core.model.OwnerSession
import com.example.core.model.ThemePreference
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.PreferencesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AppUiState(
    val language: AppLanguage = AppLanguage.MYANMAR,
    val themePreference: ThemePreference = ThemePreference.SYSTEM,
    val session: OwnerSession? = null,
)

class AppViewModel(
    private val preferencesRepository: PreferencesRepository,
    private val authRepository: AuthRepository,
) : ViewModel() {

    val uiState: StateFlow<AppUiState> = combine(
        preferencesRepository.languageFlow,
        preferencesRepository.themePreferenceFlow,
        authRepository.sessionState,
    ) { language, themePreference, session ->
        AppUiState(
            language = language,
            themePreference = themePreference,
            session = session,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = AppUiState(),
    )

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            preferencesRepository.setLanguage(language)
        }
    }

    fun toggleLanguage() {
        val next = if (uiState.value.language == AppLanguage.MYANMAR) {
            AppLanguage.ENGLISH
        } else {
            AppLanguage.MYANMAR
        }
        setLanguage(next)
    }

    fun setThemePreference(preference: ThemePreference) {
        viewModelScope.launch {
            preferencesRepository.setThemePreference(preference)
        }
    }

    fun signOut() {
        viewModelScope.launch {
            authRepository.signOut()
        }
    }

    class Factory(
        private val preferencesRepository: PreferencesRepository,
        private val authRepository: AuthRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AppViewModel(preferencesRepository, authRepository) as T
        }
    }
}
