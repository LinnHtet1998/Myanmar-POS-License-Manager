package com.example.ui.navigation

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.di.AppContainer
import com.example.ui.components.PrimaryTab
import com.example.ui.components.ResponsiveOwnerShell
import com.example.ui.components.SignOutConfirmationDialog
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.dashboard.DashboardViewModel
import com.example.ui.screens.licenses.LicensesScreen
import com.example.ui.screens.login.LoginScreen
import com.example.ui.screens.login.LoginViewModel
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.AppViewModel

@Composable
fun AppNavHost(
    appContainer: AppContainer,
    appViewModel: AppViewModel,
    appUiState: AppUiState,
) {
    var showSignOutDialog by remember { mutableStateOf(false) }

    if (showSignOutDialog) {
        SignOutConfirmationDialog(
            onDismiss = { showSignOutDialog = false },
            onConfirm = {
                showSignOutDialog = false
                appViewModel.signOut()
            },
        )
    }

    AnimatedContent(
        targetState = appUiState.session != null,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "auth_session_transition",
    ) { isAuthenticated ->
        if (!isAuthenticated) {
            val loginViewModel: LoginViewModel = viewModel(
                factory = LoginViewModel.Factory(appContainer.authRepository),
            )
            LoginScreen(
                viewModel = loginViewModel,
                currentLanguage = appUiState.language,
                onToggleLanguage = appViewModel::toggleLanguage,
                onAuthenticated = { /* Session StateFlow triggers transition to Owner Shell */ },
            )
        } else {
            val navController = rememberNavController()
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            val selectedTab = when {
                currentDestination?.hasRoute<LicensesRoute>() == true -> PrimaryTab.LICENSES
                currentDestination?.hasRoute<SettingsRoute>() == true -> PrimaryTab.SETTINGS
                else -> PrimaryTab.DASHBOARD
            }

            fun navigateToTab(tab: PrimaryTab) {
                val route: Any = when (tab) {
                    PrimaryTab.DASHBOARD -> DashboardRoute
                    PrimaryTab.LICENSES -> LicensesRoute
                    PrimaryTab.SETTINGS -> SettingsRoute
                }
                navController.navigate(route) {
                    popUpTo<DashboardRoute> {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }
            }

            ResponsiveOwnerShell(
                selectedTab = selectedTab,
                currentLanguage = appUiState.language,
                onSelectTab = ::navigateToTab,
                onToggleLanguage = appViewModel::toggleLanguage,
                onRequestSignOut = { showSignOutDialog = true },
            ) { widthSize ->
                NavHost(
                    navController = navController,
                    startDestination = DashboardRoute,
                ) {
                    composable<DashboardRoute> {
                        val dashboardViewModel: DashboardViewModel = viewModel(
                            factory = DashboardViewModel.Factory(
                                authRepository = appContainer.authRepository,
                                licenseRepository = appContainer.licenseRepository,
                            ),
                        )
                        DashboardScreen(
                            viewModel = dashboardViewModel,
                            widthSize = widthSize,
                            onNavigateToLicenses = { navigateToTab(PrimaryTab.LICENSES) },
                            onNavigateToSettings = { navigateToTab(PrimaryTab.SETTINGS) },
                        )
                    }

                    composable<LicensesRoute> {
                        LicensesScreen(
                            widthSize = widthSize,
                            onReturnToDashboard = { navigateToTab(PrimaryTab.DASHBOARD) },
                        )
                    }

                    composable<SettingsRoute> {
                        SettingsScreen(
                            currentLanguage = appUiState.language,
                            currentTheme = appUiState.themePreference,
                            ownerEmail = appUiState.session?.email.orEmpty(),
                            widthSize = widthSize,
                            onSelectLanguage = appViewModel::setLanguage,
                            onSelectTheme = appViewModel::setThemePreference,
                            onRequestSignOut = { showSignOutDialog = true },
                        )
                    }
                }
            }
        }
    }
}
