package com.example.ui.screens.login

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.localization.LocalAppStrings
import com.example.core.model.AppLanguage
import com.example.domain.repository.AuthValidationError
import com.example.ui.components.BrandEmblemBadge
import com.example.ui.components.LanguageTogglePill
import com.example.ui.components.StageStatusChip
import com.example.ui.theme.LocalSemanticColors

@Composable
fun LoginScreen(
    viewModel: LoginViewModel,
    currentLanguage: AppLanguage,
    onToggleLanguage: () -> Unit,
    onAuthenticated: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        val isWideScreen = maxWidth >= 720.dp

        if (isWideScreen) {
            Row(modifier = Modifier.fillMaxSize()) {
                BrandShowcasePanel(
                    modifier = Modifier
                        .weight(0.46f)
                        .fillMaxHeight(),
                )

                Box(
                    modifier = Modifier
                        .weight(0.54f)
                        .fillMaxHeight()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .imePadding(),
                ) {
                    LanguageTogglePill(
                        currentLanguage = currentLanguage,
                        onToggle = onToggleLanguage,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 16.dp, end = 24.dp),
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 36.dp, vertical = 72.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        LoginFormContent(
                            uiState = uiState,
                            onEmailChanged = viewModel::onEmailChanged,
                            onPasswordChanged = viewModel::onPasswordChanged,
                            onTogglePasswordVisibility = viewModel::togglePasswordVisibility,
                            onSubmit = { viewModel.submit(onAuthenticated) },
                            modifier = Modifier.widthIn(max = 440.dp),
                        )
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .imePadding(),
            ) {
                PhoneLoginHeroHeader(
                    currentLanguage = currentLanguage,
                    onToggleLanguage = onToggleLanguage,
                )

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset(y = (-24).dp),
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        LoginFormContent(
                            uiState = uiState,
                            onEmailChanged = viewModel::onEmailChanged,
                            onPasswordChanged = viewModel::onPasswordChanged,
                            onTogglePasswordVisibility = viewModel::togglePasswordVisibility,
                            onSubmit = { viewModel.submit(onAuthenticated) },
                            modifier = Modifier.widthIn(max = 500.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PhoneLoginHeroHeader(
    currentLanguage: AppLanguage,
    onToggleLanguage: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val semantic = LocalSemanticColors.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(semantic.brandBannerStart, semantic.brandBannerEnd)
                )
            ),
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_owner_portal_banner),
            contentDescription = strings.appName,
            contentScale = ContentScale.Crop,
            alpha = 0.42f,
            modifier = Modifier.fillMaxSize(),
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            semantic.brandBannerStart.copy(alpha = 0.55f),
                            semantic.brandBannerEnd.copy(alpha = 0.92f),
                        )
                    )
                ),
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    BrandEmblemBadge(size = 38.dp)
                    Text(
                        text = "MYANMAR POS",
                        style = MaterialTheme.typography.labelLarge,
                        color = semantic.brandGoldAccent,
                    )
                }

                LanguageTogglePill(
                    currentLanguage = currentLanguage,
                    onToggle = onToggleLanguage,
                    containerColor = Color.White.copy(alpha = 0.14f),
                    contentColor = Color.White,
                )
            }

            Column(modifier = Modifier.padding(bottom = 26.dp)) {
                Text(
                    text = strings.appName,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.appTagline,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f),
                )
            }
        }
    }
}

@Composable
private fun BrandShowcasePanel(
    modifier: Modifier = Modifier,
) {
    val strings = LocalAppStrings.current
    val semantic = LocalSemanticColors.current

    Box(
        modifier = modifier.background(
            brush = Brush.verticalGradient(
                colors = listOf(semantic.brandBannerStart, semantic.brandBannerEnd)
            )
        ),
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_owner_portal_banner),
            contentDescription = strings.appName,
            contentScale = ContentScale.Crop,
            alpha = 0.35f,
            modifier = Modifier.fillMaxSize(),
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            semantic.brandBannerStart.copy(alpha = 0.58f),
                            semantic.brandBannerEnd.copy(alpha = 0.94f),
                        )
                    )
                ),
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(36.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                BrandEmblemBadge(size = 48.dp)
                Column {
                    Text(
                        text = strings.appName,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                    )
                    Text(
                        text = strings.stageOneBadge,
                        style = MaterialTheme.typography.labelMedium,
                        color = semantic.brandGoldAccent,
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.img_owner_portal_banner),
                    contentDescription = strings.loginHeroTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(MaterialTheme.shapes.large),
                )

                Text(
                    text = strings.loginHeroTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                )

                Text(
                    text = strings.loginHeroBody,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.86f),
                )
            }

            Surface(
                shape = MaterialTheme.shapes.medium,
                color = Color.White.copy(alpha = 0.1f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
            ) {
                Text(
                    text = strings.standaloneNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                )
            }
        }
    }
}

@Composable
private fun LoginFormContent(
    uiState: LoginUiState,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onTogglePasswordVisibility: () -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val strings = LocalAppStrings.current
    val focusManager = LocalFocusManager.current

    val emailErrorText = when (uiState.emailError) {
        AuthValidationError.EMAIL_REQUIRED -> strings.emailRequiredError
        AuthValidationError.EMAIL_INVALID -> strings.emailInvalidError
        else -> null
    }
    val passwordErrorText = when (uiState.passwordError) {
        AuthValidationError.PASSWORD_REQUIRED -> strings.passwordRequiredError
        AuthValidationError.PASSWORD_TOO_SHORT -> strings.passwordTooShortError
        else -> null
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        StageStatusChip(text = strings.stageOneBadge)

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = strings.loginTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = strings.loginSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        OutlinedTextField(
            value = uiState.email,
            onValueChange = onEmailChanged,
            label = { Text(strings.emailLabel) },
            placeholder = { Text(strings.emailPlaceholder) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Email,
                    contentDescription = strings.emailLabel,
                )
            },
            singleLine = true,
            isError = emailErrorText != null,
            supportingText = emailErrorText?.let { err -> { Text(err) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Next,
            ),
            keyboardActions = KeyboardActions(
                onNext = { focusManager.moveFocus(FocusDirection.Down) },
            ),
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("owner_email_input"),
        )

        OutlinedTextField(
            value = uiState.password,
            onValueChange = onPasswordChanged,
            label = { Text(strings.passwordLabel) },
            placeholder = { Text(strings.passwordPlaceholder) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Lock,
                    contentDescription = strings.passwordLabel,
                )
            },
            trailingIcon = {
                IconButton(
                    onClick = onTogglePasswordVisibility,
                    modifier = Modifier.testTag("toggle_password_visibility"),
                ) {
                    Icon(
                        imageVector = if (uiState.isPasswordVisible) {
                            Icons.Outlined.VisibilityOff
                        } else {
                            Icons.Outlined.Visibility
                        },
                        contentDescription = if (uiState.isPasswordVisible) {
                            strings.hidePasswordDesc
                        } else {
                            strings.showPasswordDesc
                        },
                    )
                }
            },
            visualTransformation = if (uiState.isPasswordVisible) {
                VisualTransformation.None
            } else {
                PasswordVisualTransformation()
            },
            singleLine = true,
            isError = passwordErrorText != null,
            supportingText = passwordErrorText?.let { err -> { Text(err) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done,
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    focusManager.clearFocus()
                    onSubmit()
                },
            ),
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("owner_password_input"),
        )

        Button(
            onClick = {
                focusManager.clearFocus()
                onSubmit()
            },
            enabled = !uiState.isSubmitting,
            shape = MaterialTheme.shapes.medium,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("owner_login_button"),
        ) {
            if (uiState.isSubmitting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary,
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = strings.signingInLabel,
                    style = MaterialTheme.typography.labelLarge,
                )
            } else {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Login,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = strings.signInButton,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }

        Surface(
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = strings.stageOneAuthNoteTitle,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(top = 2.dp)
                        .size(20.dp),
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.stageOneAuthNoteTitle,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = strings.stageOneAuthNoteBody,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
