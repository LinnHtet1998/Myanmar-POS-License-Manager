package com.example.ui.screens.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.PauseCircle
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.localization.LocalAppStrings
import com.example.core.model.ReadinessRoadmapItem
import com.example.core.model.RoadmapStepId
import com.example.core.model.WindowWidthSize
import com.example.ui.components.DashboardMetricCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StageStatusChip
import com.example.ui.theme.LocalSemanticColors

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    widthSize: WindowWidthSize,
    onNavigateToLicenses: () -> Unit,
    onNavigateToSettings: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val strings = LocalAppStrings.current
    val semantic = LocalSemanticColors.current

    val isExpanded = widthSize == WindowWidthSize.EXPANDED
    val isMediumOrExpanded = widthSize != WindowWidthSize.COMPACT

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 1160.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            // 1. Hero Welcome Banner
            item {
                WelcomeHeroCard(
                    ownerEmail = uiState.ownerEmail,
                )
            }

            // 2. KPI Overview Grid (2x2 on Phone, 4-in-row on Expanded Tablet)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(
                        title = strings.kpiSectionTitle,
                        subtitle = strings.kpiAwaitingFirebase,
                    )

                    val metrics = listOf(
                        MetricSpec(
                            title = strings.kpiTotalLicenses,
                            value = uiState.overview.totalLicenses?.toString() ?: "—",
                            icon = Icons.Outlined.VpnKey,
                            accent = MaterialTheme.colorScheme.primary,
                            container = MaterialTheme.colorScheme.primaryContainer,
                        ),
                        MetricSpec(
                            title = strings.kpiActiveTerminals,
                            value = uiState.overview.activeTerminals?.toString() ?: "—",
                            icon = Icons.Outlined.Devices,
                            accent = semantic.success,
                            container = semantic.successContainer,
                        ),
                        MetricSpec(
                            title = strings.kpiExpiringSoon,
                            value = uiState.overview.expiringSoon?.toString() ?: "—",
                            icon = Icons.Outlined.Schedule,
                            accent = semantic.warning,
                            container = semantic.warningContainer,
                        ),
                        MetricSpec(
                            title = strings.kpiSuspended,
                            value = uiState.overview.revokedOrPaused?.toString() ?: "—",
                            icon = Icons.Outlined.PauseCircle,
                            accent = MaterialTheme.colorScheme.error,
                            container = MaterialTheme.colorScheme.errorContainer,
                        ),
                    )

                    if (isExpanded) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            metrics.forEach { spec ->
                                DashboardMetricCard(
                                    title = spec.title,
                                    valueDisplay = spec.value,
                                    subtitle = strings.kpiAwaitingFirebase,
                                    icon = spec.icon,
                                    accentColor = spec.accent,
                                    accentContainerColor = spec.container,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                DashboardMetricCard(
                                    title = metrics[0].title,
                                    valueDisplay = metrics[0].value,
                                    subtitle = strings.kpiAwaitingFirebase,
                                    icon = metrics[0].icon,
                                    accentColor = metrics[0].accent,
                                    accentContainerColor = metrics[0].container,
                                    modifier = Modifier.weight(1f),
                                )
                                DashboardMetricCard(
                                    title = metrics[1].title,
                                    valueDisplay = metrics[1].value,
                                    subtitle = strings.kpiAwaitingFirebase,
                                    icon = metrics[1].icon,
                                    accentColor = metrics[1].accent,
                                    accentContainerColor = metrics[1].container,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                DashboardMetricCard(
                                    title = metrics[2].title,
                                    valueDisplay = metrics[2].value,
                                    subtitle = strings.kpiAwaitingFirebase,
                                    icon = metrics[2].icon,
                                    accentColor = metrics[2].accent,
                                    accentContainerColor = metrics[2].container,
                                    modifier = Modifier.weight(1f),
                                )
                                DashboardMetricCard(
                                    title = metrics[3].title,
                                    valueDisplay = metrics[3].value,
                                    subtitle = strings.kpiAwaitingFirebase,
                                    icon = metrics[3].icon,
                                    accentColor = metrics[3].accent,
                                    accentContainerColor = metrics[3].container,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                }
            }

            // 3. Quick Navigation Cards
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(title = strings.quickActionsTitle)

                    if (isMediumOrExpanded) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            QuickActionTile(
                                title = strings.actionOpenLicensesTitle,
                                subtitle = strings.actionOpenLicensesSubtitle,
                                icon = Icons.Outlined.VpnKey,
                                onClick = onNavigateToLicenses,
                                testTag = "quick_action_licenses",
                                modifier = Modifier.weight(1f),
                            )
                            QuickActionTile(
                                title = strings.actionOpenSettingsTitle,
                                subtitle = strings.actionOpenSettingsSubtitle,
                                icon = Icons.Outlined.Settings,
                                onClick = onNavigateToSettings,
                                testTag = "quick_action_settings",
                                modifier = Modifier.weight(1f),
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            QuickActionTile(
                                title = strings.actionOpenLicensesTitle,
                                subtitle = strings.actionOpenLicensesSubtitle,
                                icon = Icons.Outlined.VpnKey,
                                onClick = onNavigateToLicenses,
                                testTag = "quick_action_licenses",
                            )
                            QuickActionTile(
                                title = strings.actionOpenSettingsTitle,
                                subtitle = strings.actionOpenSettingsSubtitle,
                                icon = Icons.Outlined.Settings,
                                onClick = onNavigateToSettings,
                                testTag = "quick_action_settings",
                            )
                        }
                    }
                }
            }

            // 4. Roadmap + Recent Activity Empty State (Side-by-side on Tablet, stacked on Phone)
            item {
                if (isMediumOrExpanded) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        RoadmapCard(
                            items = uiState.roadmapItems,
                            modifier = Modifier.weight(1.1f),
                        )
                        RecentActivityEmptyCard(
                            modifier = Modifier.weight(0.9f),
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        RoadmapCard(items = uiState.roadmapItems)
                        RecentActivityEmptyCard()
                    }
                }
            }
        }
    }
}

private data class MetricSpec(
    val title: String,
    val value: String,
    val icon: ImageVector,
    val accent: Color,
    val container: Color,
)

@Composable
private fun WelcomeHeroCard(
    ownerEmail: String,
) {
    val strings = LocalAppStrings.current
    val semantic = LocalSemanticColors.current

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(semantic.brandBannerStart, semantic.brandBannerEnd)
                    )
                ),
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_owner_portal_banner),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.24f,
                modifier = Modifier.matchParentSize(),
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StageStatusChip(
                        text = strings.backendPendingChip,
                        containerColor = Color.White.copy(alpha = 0.16f),
                        contentColor = semantic.brandGoldAccent,
                    )
                }

                Text(
                    text = if (ownerEmail.isNotBlank()) {
                        "${strings.dashboardWelcomePrefix}၊ $ownerEmail"
                    } else {
                        strings.dashboardWelcomePrefix
                    },
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )

                Text(
                    text = strings.dashboardSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f),
                )
            }
        }
    }
}

@Composable
private fun QuickActionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier,
) {
    OutlinedCard(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.outlinedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun RoadmapCard(
    items: List<ReadinessRoadmapItem>,
    modifier: Modifier = Modifier,
) {
    val strings = LocalAppStrings.current
    val semantic = LocalSemanticColors.current

    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SectionHeader(
                title = strings.roadmapTitle,
                subtitle = strings.roadmapSubtitle,
            )

            items.forEachIndexed { index, item ->
                val (title, desc) = when (item.id) {
                    RoadmapStepId.ARCHITECTURE_AND_NAV -> strings.roadmapStep1Title to strings.roadmapStep1Desc
                    RoadmapStepId.RESPONSIVE_BURMESE_UI -> strings.roadmapStep2Title to strings.roadmapStep2Desc
                    RoadmapStepId.FIREBASE_AUTH_SYNC -> strings.roadmapStep3Title to strings.roadmapStep3Desc
                    RoadmapStepId.LICENSE_KEY_LIFECYCLE -> strings.roadmapStep4Title to strings.roadmapStep4Desc
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(
                        imageVector = if (item.isReadyInStageOne) {
                            Icons.Outlined.CheckCircle
                        } else {
                            Icons.Outlined.Schedule
                        },
                        contentDescription = title,
                        tint = if (item.isReadyInStageOne) {
                            semantic.success
                        } else {
                            MaterialTheme.colorScheme.secondary
                        },
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .size(20.dp),
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = desc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (item.isReadyInStageOne) {
                            semantic.successContainer
                        } else {
                            MaterialTheme.colorScheme.secondaryContainer
                        },
                    ) {
                        Text(
                            text = if (item.isReadyInStageOne) {
                                strings.roadmapCompletedBadge
                            } else {
                                strings.roadmapStageTwoBadge
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (item.isReadyInStageOne) {
                                semantic.success
                            } else {
                                MaterialTheme.colorScheme.onSecondaryContainer
                            },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                }

                if (index < items.lastIndex) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@Composable
private fun RecentActivityEmptyCard(
    modifier: Modifier = Modifier,
) {
    val strings = LocalAppStrings.current

    OutlinedCard(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.outlinedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionHeader(
                title = strings.recentActivityTitle,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Outlined.History,
                    contentDescription = strings.recentActivityEmptyTitle,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp),
                )
            }

            Text(
                text = strings.recentActivityEmptyTitle,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )

            Text(
                text = strings.recentActivityEmptyBody,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
