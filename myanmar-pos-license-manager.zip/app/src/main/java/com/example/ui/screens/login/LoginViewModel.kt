package com.example.ui.screens.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.repository.AuthOutcome
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.AuthValidationError
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val isPasswordVisible: Boolean = false,
    val isSubmitting: Boolean = false,
    val emailError: AuthValidationError? = null,
    val passwordError: AuthValidationError? = null,
)

class LoginViewModel(
    private val authRepository: AuthRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onEmailChanged(newValue: String) {
        _uiState.update {
            it.copy(
                email = newValue,
                emailError = null,
            )
        }
    }

    fun onPasswordChanged(newValue: String) {
        _uiState.update {
            it.copy(
                password = newValue,
                passwordError = null,
            )
        }
    }

    fun togglePasswordVisibility() {
        _uiState.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    }

    fun submit(onAuthenticated: () -> Unit) {
        val current = _uiState.value
        if (current.isSubmitting) return

        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true, emailError = null, passwordError = null) }
            when (val outcome = authRepository.signIn(current.email, current.password)) {
                is AuthOutcome.Success -> {
                    _uiState.update { it.copy(isSubmitting = false, password = "") }
                    onAuthenticated()
                }
                is AuthOutcome.ValidationError -> {
                    val emailErr = when (outcome.reason) {
                        AuthValidationError.EMAIL_REQUIRED,
                        AuthValidationError.EMAIL_INVALID -> outcome.reason
                        else -> null
                    }
                    val passwordErr = when (outcome.reason) {
                        AuthValidationError.PASSWORD_REQUIRED,
                        AuthValidationError.PASSWORD_TOO_SHORT -> outcome.reason
                        else -> null
                    }
                    _uiState.update {
                        it.copy(
                            isSubmitting = false,
                            emailError = emailErr,
                            passwordError = passwordErr,
                        )
                    }
                }
            }
        }
    }

    class Factory(
        private val authRepository: AuthRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LoginViewModel(authRepository) as T
        }
    }
}
