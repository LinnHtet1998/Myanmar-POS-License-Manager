package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
data object LoginRoute

@Serializable
data object DashboardRoute

@Serializable
data object LicensesRoute

@Serializable
data object SettingsRoute
