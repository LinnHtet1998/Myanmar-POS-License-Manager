package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.AppLanguage
import com.example.core.model.ThemePreference
import com.example.domain.repository.PreferencesRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.ownerPreferencesDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "owner_console_preferences"
)

class DataStorePreferencesRepository(
    private val context: Context,
) : PreferencesRepository {

    override val languageFlow: Flow<AppLanguage> =
        context.ownerPreferencesDataStore.data.map { prefs ->
            AppLanguage.fromCode(prefs[KEY_LANGUAGE])
        }

    override val themePreferenceFlow: Flow<ThemePreference> =
        context.ownerPreferencesDataStore.data.map { prefs ->
            ThemePreference.fromKey(prefs[KEY_THEME])
        }

    override suspend fun setLanguage(language: AppLanguage) {
        context.ownerPreferencesDataStore.edit { prefs ->
            prefs[KEY_LANGUAGE] = language.code
        }
    }

    override suspend fun setThemePreference(preference: ThemePreference) {
        context.ownerPreferencesDataStore.edit { prefs ->
            prefs[KEY_THEME] = preference.key
        }
    }

    private companion object {
        val KEY_LANGUAGE = stringPreferencesKey("app_language")
        val KEY_THEME = stringPreferencesKey("theme_preference")
    }
}
