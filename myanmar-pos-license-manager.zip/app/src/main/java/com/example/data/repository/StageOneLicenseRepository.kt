package com.example.data.repository

import com.example.core.model.LicenseOverviewSnapshot
import com.example.domain.repository.LicenseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Stage 1 placeholder license repository.
 * Emits an unconnected empty snapshot so no fake activation keys or fabricated
 * counts are displayed before Firebase Firestore is connected in Stage 2.
 */
class StageOneLicenseRepository : LicenseRepository {
    private val _overviewState = MutableStateFlow(
        LicenseOverviewSnapshot(
            totalLicenses = null,
            activeTerminals = null,
            expiringSoon = null,
            revokedOrPaused = null,
            isBackendConnected = false,
        )
    )
    override val overviewState: StateFlow<LicenseOverviewSnapshot> = _overviewState.asStateFlow()
}
