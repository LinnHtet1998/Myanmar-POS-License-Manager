package com.example.data.repository

import com.example.core.model.OwnerSession
import com.example.domain.repository.AuthOutcome
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.AuthValidationError
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Stage 1 local authentication handler.
 *
 * Intentionally contains NO fake owner accounts, NO pre-seeded credentials,
 * and NO Firebase dependency yet. Validates user-entered input format locally
 * so the Owner Login -> Dashboard navigation flow can be exercised cleanly
 * prior to Stage 2 Firebase Auth integration.
 */
class LocalStageOneAuthRepository : AuthRepository {

    private val _sessionState = MutableStateFlow<OwnerSession?>(null)
    override val sessionState: StateFlow<OwnerSession?> = _sessionState.asStateFlow()

    override suspend fun signIn(email: String, password: String): AuthOutcome {
        val trimmedEmail = email.trim()
        if (trimmedEmail.isEmpty()) {
            return AuthOutcome.ValidationError(AuthValidationError.EMAIL_REQUIRED)
        }
        if (!EMAIL_REGEX.matches(trimmedEmail)) {
            return AuthOutcome.ValidationError(AuthValidationError.EMAIL_INVALID)
        }
        if (password.isEmpty()) {
            return AuthOutcome.ValidationError(AuthValidationError.PASSWORD_REQUIRED)
        }
        if (password.length < MIN_PASSWORD_LENGTH) {
            return AuthOutcome.ValidationError(AuthValidationError.PASSWORD_TOO_SHORT)
        }

        // Brief realistic state transition for UI responsiveness.
        delay(220L)

        val session = OwnerSession(
            email = trimmedEmail,
            signedInAtMillis = System.currentTimeMillis(),
            isStageOneLocalSession = true,
        )
        _sessionState.value = session
        return AuthOutcome.Success(session)
    }

    override suspend fun signOut() {
        _sessionState.value = null
    }

    private companion object {
        const val MIN_PASSWORD_LENGTH = 6
        val EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
    }
}
