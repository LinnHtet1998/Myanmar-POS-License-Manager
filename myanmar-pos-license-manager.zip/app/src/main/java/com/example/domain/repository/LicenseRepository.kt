package com.example.domain.repository

import com.example.core.model.LicenseOverviewSnapshot
import kotlinx.coroutines.flow.StateFlow

/**
 * Abstraction for license telemetry and management.
 * Stage 1 exposes an unconnected placeholder snapshot.
 * Stage 2 will swap in a Cloud Firestore implementation.
 */
interface LicenseRepository {
    val overviewState: StateFlow<LicenseOverviewSnapshot>
}
