package com.example.domain.repository

import com.example.core.model.AppLanguage
import com.example.core.model.ThemePreference
import kotlinx.coroutines.flow.Flow

interface PreferencesRepository {
    val languageFlow: Flow<AppLanguage>
    val themePreferenceFlow: Flow<ThemePreference>
    suspend fun setLanguage(language: AppLanguage)
    suspend fun setThemePreference(preference: ThemePreference)
}
