package com.example.domain.repository

import com.example.core.model.OwnerSession
import kotlinx.coroutines.flow.StateFlow

sealed interface AuthOutcome {
    data class Success(val session: OwnerSession) : AuthOutcome
    data class ValidationError(val reason: AuthValidationError) : AuthOutcome
}

enum class AuthValidationError {
    EMAIL_REQUIRED,
    EMAIL_INVALID,
    PASSWORD_REQUIRED,
    PASSWORD_TOO_SHORT,
}

/**
 * Abstraction for owner authentication.
 * Stage 1 uses [com.example.data.repository.LocalStageOneAuthRepository].
 * Stage 2 will swap in a FirebaseAuth-backed implementation without altering ViewModels.
 */
interface AuthRepository {
    val sessionState: StateFlow<OwnerSession?>
    suspend fun signIn(email: String, password: String): AuthOutcome
    suspend fun signOut()
}
