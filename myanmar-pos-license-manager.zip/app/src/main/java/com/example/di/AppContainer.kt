package com.example.di

import android.content.Context
import com.example.data.repository.DataStorePreferencesRepository
import com.example.data.repository.LocalStageOneAuthRepository
import com.example.data.repository.StageOneLicenseRepository
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.LicenseRepository
import com.example.domain.repository.PreferencesRepository

/**
 * Lightweight constructor-injection container.
 * In Stage 2, replace [LocalStageOneAuthRepository] and [StageOneLicenseRepository]
 * with Firebase Auth and Cloud Firestore implementations here.
 */
class AppContainer(context: Context) {
    val preferencesRepository: PreferencesRepository = DataStorePreferencesRepository(context.applicationContext)
    val authRepository: AuthRepository = LocalStageOneAuthRepository()
    val licenseRepository: LicenseRepository = StageOneLicenseRepository()
}
